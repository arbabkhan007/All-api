==========================================================
 WEDDING PLANNER SPREADSHEET - VERSION 2  (ALL-IN-ONE)
 by NOVALITY STORE
==========================================================

THANK YOU! Everything is in this one folder:

  Wedding_Planner_V2_Novality_Store.xlsx
      The finished 52-tab planner. Open it in Microsoft
      Excel (recommended) or Google Sheets and start with
      the "Start Here" tab.

  1_Etsy_Listing_Kit/
      images/        10 listing images (2700x2025) in upload order
      pin_01/pin_02  2 Pinterest pins (1000x1500)
      LISTING_KIT.md Title, 13 tags, description, alt text, pricing
      assets/        Floral background art used by the graphics
      contact_sheet.jpg  Preview of all 10 slides

  2_Source_Code/
      Wedding_Planner_V2_SOURCE_CODE.txt   All 17 files in one text
      wedding_planner_v2/                  The real Python modules
      Rebuild:  pip install openpyxl
                python3 -m wedding_planner_v2.build

  3_Marketing/
      LISTING_KIT.md                 Copy-paste listing copy
      SOURCE_CODE_DESCRIPTION.md     Description pack for the source

PASSWORD
  Formula sheets are locked to protect the calculations:
        password:  premium
  (Review > Unprotect Sheet in Excel to customize.)

TERMS
  (c) Novality Store - Version 2.0 - digital product, personal use.
  Happy planning! 💐
